<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Rute umum (tanpa filter auth)
$routes->get('/', 'HomeController::index');  // Home page
$routes->get('/explore', 'HomeController::explore');  // Home page
$routes->get('/rekom_rooms', 'HomeController::rekom_rooms');  // Home page
$routes->get('/login', 'AuthController::login');  // Login page
$routes->post('/login', 'LoginController::login');
$routes->get('/logout', 'LoginController::logout'); // Route untuk logout
$routes->get('/register', 'AuthController::register'); // Register page
$routes->post('/register', 'AuthController::store'); // Proses Register
$routes->get('/index2', 'RatingController::index2'); 
// Rute untuk Dashboard (Admin)
$routes->get('/dashboard', 'TemplateController::index');  // Halaman untuk Admin

// Rute untuk Rooms (Memerlukan autentikasi)
$routes->group('room', function($routes) {
    $routes->get('/', 'RoomController::index'); // Menampilkan daftar kamar
    $routes->get('create', 'RoomController::create'); // Menampilkan form tambah kamar
    $routes->post('store', 'RoomController::store'); // Menyimpan kamar baru
    $routes->get('details/(:num)', 'RoomController::details/$1');
    $routes->get('edit/(:num)', 'RoomController::edit/$1'); // Menampilkan form edit kamar
    $routes->post('update/(:num)', 'RoomController::update/$1'); // Menyimpan perubahan kamar
    $routes->get('delete/(:num)', 'RoomController::delete/$1'); // Menghapus kamar
   
});

// Rute untuk Rating (Memerlukan autentikasi)
$routes->group('rating', function($routes) {
    $routes->get('/', 'RatingController::index'); // Menampilkan daftar rating
    $routes->get('create', 'RatingController::create'); // Menampilkan form tambah rating
    $routes->post('store', 'RatingController::store'); // Menyimpan rating baru
    $routes->get('edit/(:num)', 'RatingController::edit/$1'); // Menampilkan form edit rating
    $routes->post('update/(:num)', 'RatingController::update/$1'); // Menyimpan perubahan rating
    $routes->get('delete/(:num)', 'RatingController::delete/$1'); // Menghapus rating
    $routes->post('submit_rating', 'RatingController::submit_rating'); // Menyimpan kamar baru
});

// Rute untuk User (Memerlukan autentikasi untuk Admin)
$routes->group('user', function($routes) {
    $routes->get('/', 'UserController::index'); // Menampilkan daftar user
    $routes->get('create', 'UserController::create'); // Menampilkan form tambah user
    $routes->post('store', 'UserController::store'); // Menyimpan user baru
    $routes->get('edit/(:segment)', 'UserController::edit/$1'); // Menampilkan form edit user
    $routes->post('update/(:segment)', 'UserController::update/$1'); // Menyimpan perubahan user
    $routes->get('delete/(:segment)', 'UserController::delete/$1'); // Menghapus user
});
