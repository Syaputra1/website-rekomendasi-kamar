<?php

namespace App\Controllers;
use App\Models\ItemModel;
use App\Models\UserModel;
use CodeIgniter\Controller;

class AuthController extends Controller
{

    public function login()
    {
        return view('login');
    }
    

    // Menampilkan halaman register
    public function register()
    {
        return view('register');
    }

    // Menyimpan data register
    public function store()
    {
        // Validasi form
        $validation =  \Config\Services::validation();

        if (!$this->validate([
            'username' => 'required|min_length[3]',
            'email' => 'required|valid_email',
            'password' => 'required|min_length[6]',
            'confirm_password' => 'matches[password]'
        ])) {
            // Jika validasi gagal, kirim pesan error dan kembali ke form
            return redirect()->to('/register')->withInput()->with('errors', $validation->getErrors());
        }

        // Ambil data dari form
        $data = [
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'jenis_kelamin' => $this->request->getPost('gender'),
            'umur' => $this->request->getPost('age'),
            'status' => $this->request->getPost('job'),
            'role' => 'User',
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
        ];

        // Simpan data user ke database (Anda harus memiliki model untuk ini)
        // Misalnya menggunakan model UserModel
        $userModel = new UserModel();
        $userModel->save($data);

        // Redirect ke login setelah registrasi berhasil
        return redirect()->to('/login')->with('message', 'Pendaftaran berhasil, silakan login.');
    }
}
