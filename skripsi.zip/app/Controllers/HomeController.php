<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\RecommendationModel;
use App\Models\RoomModel;

class HomeController extends Controller
{

    protected $db;
    protected $roomModel;

    public function __construct()
    {
        // Inisialisasi database
        $this->db = db_connect();
        $this->roomModel = new RoomModel();
    }
    public function index()
    {
        $db = \Config\Database::connect(); // Koneksi database
        $data['rooms'] = $db->table('rooms')
            ->select('rooms.*, ratings.rating')
            ->join('ratings', 'ratings.room_id = rooms.id', 'left')
            ->get()
            ->getResultArray();
        return view('home', $data);
    }

    // public function explore()
    // {
    //     $userId = session()->get('user_id'); // Pastikan user login
    //     if (!$userId) {
    //         return redirect()->to('/login')->with('error', 'Silakan login terlebih dahulu.');
    //     }

    //     $db = \Config\Database::connect(); // Koneksi database

    //     // Step 1: Hapus data rekomendasi lama untuk user ini
    //     $db->table('rekom_rooms')->where('user_id', $userId)->delete();

    //     // Step 2: Ambil data rating untuk user tertentu
    //     $usedRooms = $db->table('ratings')
    //     ->select('room_id')
    //     ->where('user_id', $userId)
    //     ->where('sudah_sewa', 'no')
    //     // ->where('sudah_sewa IS NULL')  // Replacing whereNull with explicit 'IS NULL' condition
    //     ->get()
    //     ->getResultArray();


    //     // Step 3: Dapatkan ID room yang sudah digunakan oleh user
    //     $usedRoomIds = array_column($usedRooms, 'room_id');

    //     // Step 4: Ambil semua room yang belum digunakan oleh user
    //     $availableRooms = empty($usedRoomIds)
    //         ? $db->table('rooms')->select('id, name')->get()->getResultArray()
    //         : $db->table('rooms')
    //             ->select('id, name')
    //             ->whereNotIn('id', $usedRoomIds)
    //             ->get()
    //             ->getResultArray();

    //     // Step 5: Simpan semua room yang belum digunakan ke tabel rekom_rooms
    //     foreach ($availableRooms as $room) {
    //         $db->table('rekom_rooms')->insert([
    //             'user_id' => $userId,
    //             'room_id' => $room['id'],
    //         ]);
    //     }

    //     // Step 6: Ambil data rekomendasi untuk ditampilkan
    //     $storedRecommendations = $db->table('rekom_rooms')
    //     ->select('rooms.*, ratings.rating')
    //         ->join('rooms', 'rekom_rooms.room_id = rooms.id')
    //         ->join('ratings', 'ratings.room_id = rooms.id', 'left')
    //         ->where('rekom_rooms.user_id', $userId)
    //         ->get()
    //         ->getResultArray();

    //     return view('explore', ['recommendedRooms' => $storedRecommendations]);
    // }

    public function explore()
{
    $userId = session()->get('user_id'); // Pastikan user login
    if (!$userId) {
        return redirect()->to('/login')->with('error', 'Silakan login terlebih dahulu.');
    }

    $db = \Config\Database::connect();

    // Hapus data rekomendasi sebelumnya untuk user yang sama
    $db->table('rekom_rooms')->where('user_id', $userId)->delete();

    // Ambil data kamar yang sudah disewa oleh user
    $usedRoomIds = $db->table('ratings')
        ->select('room_id')
        ->where('user_id', $userId)
        ->where('sudah_sewa', 'yes')
        ->get()
        ->getResultArray();
    
    $usedRoomIds = array_column($usedRoomIds, 'room_id');

    // Jika user belum pernah menyewa kamar
    if (empty($usedRoomIds)) {
        // Ambil semua kamar dengan rating (jika ada), diurutkan berdasarkan rating tertinggi
        $rooms = $db->table('rooms')
            ->select('rooms.*, COALESCE(AVG(ratings.rating), 0) as average_rating')
            ->join('ratings', 'ratings.room_id = rooms.id', 'left')
            ->groupBy('rooms.id')
            ->orderBy('average_rating', 'DESC')
            ->get()
            ->getResultArray();

        $recommendedRooms = [];
        foreach ($rooms as $room) {
            $recommendedRooms[] = [
                'user_id' => $userId,
                'room_id' => $room['id'],
                'name' => $room['name'],
                'rating' => $room['average_rating'],
                'type' => $room['type'],
                'image' => $room['image'],
                'price' => $room['price'],
            ];

            // Simpan rekomendasi ke tabel rekom_rooms
            $db->table('rekom_rooms')->insert([
                'user_id' => $userId,
                'room_id' => $room['id']
            ]);
        }

        return view('explore', ['recommendedRooms' => $recommendedRooms]);
    }

    // Ambil kamar yang belum disewa oleh user, diurutkan berdasarkan rating tertinggi
    $rooms = $db->table('rooms')
        ->select('rooms.*, COALESCE(AVG(ratings.rating), 0) as average_rating')
        ->join('ratings', 'ratings.room_id = rooms.id', 'left')
        ->whereNotIn('rooms.id', $usedRoomIds)
        ->groupBy('rooms.id')
        ->orderBy('average_rating', 'DESC')
        ->get()
        ->getResultArray();

    $recommendedRooms = [];
    foreach ($rooms as $room) {
        $recommendedRooms[] = [
            'user_id' => $userId,
            'room_id' => $room['id'],
            'name' => $room['name'],
            'rating' => $room['average_rating'],
            'type' => $room['type'],
            'image' => $room['image'],
            'price' => $room['price'],
        ];

        // Simpan rekomendasi ke tabel rekom_rooms
        $db->table('rekom_rooms')->insert([
            'user_id' => $userId,
            'room_id' => $room['id']
        ]);
    }

    return view('explore', ['recommendedRooms' => $recommendedRooms]);
}
    
    

    public function rekom_rooms()
    {
        $db = \Config\Database::connect(); // Koneksi database
        $rooms = $db->table('rekom_rooms')
            ->select('rooms.*, AVG(ratings.rating) as rating') // Menampilkan rating rata-rata jika ada beberapa rating untuk 1 room
            ->join('rooms', 'rekom_rooms.room_id = rooms.id')
            ->join('ratings', 'ratings.room_id = rooms.id', 'left')
            ->groupBy('rooms.id') // Kelompokkan berdasarkan id room
            ->get()
            ->getResultArray();
    
        return view('rekom_rooms/index', ['rooms' => $rooms]);
    }
    
    public function collaborative_filtering()
{
    $userId = session()->get('user_id'); // Pastikan user login
    if (!$userId) {
        return redirect()->to('/login')->with('error', 'Silakan login terlebih dahulu.');
    }

    $db = \Config\Database::connect(); // Koneksi database

    // Step 1: Ambil data rating untuk user tertentu
    $usedRooms = $db->table('ratings')
        ->select('room_id, rating')
        ->where('user_id', $userId)
        ->where('sudah_sewa', 'yes') // Hanya room yang sudah disewa
        ->get()
        ->getResultArray();

    // Jika user belum memberi rating sama sekali, return kosong
    if (empty($usedRooms)) {
        return view('explore', ['recommendedRooms' => []]);
    }

    // Organisasi data rating user
    $userRatings = [];
    foreach ($usedRooms as $rating) {
        $userRatings[$userId][$rating['room_id']] = (int)$rating['rating'];
    }

    // Step 2: Ambil rating dari semua pengguna lain
    $allRatings = $db->table('ratings')
        ->select('user_id, room_id, rating')
        ->whereNotIn('user_id', [$userId]) // Hanya ambil user lain
        ->get()
        ->getResultArray();

    // Simpan rating semua user lainnya
    foreach ($allRatings as $rating) {
        $userRatings[$rating['user_id']][$rating['room_id']] = (int)$rating['rating'];
    }

    // Step 3: Hitung Similarity antar pengguna
    $similarityScores = [];
    foreach ($userRatings as $otherUserId => $otherUserRatings) {
        if ($otherUserId == $userId) {
            continue; // Skip user yang sama
        }

        // Temukan rating yang sama antara user yang dibandingkan
        $commonRatings = array_intersect_key($userRatings[$userId] ?? [], $otherUserRatings);
        if (count($commonRatings) == 0) {
            continue; // Tidak ada rating yang sama, lanjutkan ke user lain
        }

        // Hitung Pearson Correlation
        $sumXY = $sumX = $sumY = $sumX2 = $sumY2 = 0;
        foreach ($commonRatings as $roomId => $rating) {
            $x = $userRatings[$userId][$roomId];
            $y = $otherUserRatings[$roomId];
            $sumXY += $x * $y;
            $sumX += $x;
            $sumY += $y;
            $sumX2 += $x * $x;
            $sumY2 += $y * $y;
        }

        // Menghindari pembagian dengan nol
        $denominator = sqrt($sumX2 - ($sumX * $sumX / count($commonRatings))) *
            sqrt($sumY2 - ($sumY * $sumY / count($commonRatings)));
        $similarity = $denominator == 0 ? 0 : ($sumXY - ($sumX * $sumY / count($commonRatings))) / $denominator;

        $similarityScores[$otherUserId] = $similarity;
    }

    // Step 4: Prediksi rating untuk tiap room berdasarkan Similarity
    $predictedRatings = [];
    foreach ($userRatings as $otherUserId => $otherUserRatings) {
        if (!isset($similarityScores[$otherUserId]) || $similarityScores[$otherUserId] <= 0) {
            continue; // Hanya gunakan user dengan similarity > 0
        }

        foreach ($otherUserRatings as $roomId => $rating) {
            if (isset($userRatings[$userId][$roomId])) {
                continue; // Skip room yang sudah dirating user
            }

            if (!isset($predictedRatings[$roomId])) {
                $predictedRatings[$roomId] = ['score' => 0, 'totalSimilarity' => 0];
            }

            $predictedRatings[$roomId]['score'] += $rating * $similarityScores[$otherUserId];
            $predictedRatings[$roomId]['totalSimilarity'] += $similarityScores[$otherUserId];
        }
    }

    // Step 5: Hitung skor akhir dan urutkan
    $recommendations = [];
    foreach ($predictedRatings as $roomId => $data) {
        if ($data['totalSimilarity'] > 0) {
            $recommendations[] = [
                'room_id' => $roomId,
                'score' => $data['score'] / $data['totalSimilarity']
            ];
        }
    }

    // Urutkan rekomendasi berdasarkan skor tertinggi
    usort($recommendations, function ($a, $b) {
        return $b['score'] <=> $a['score']; // Urutkan dari skor tertinggi ke terendah
    });

    // Step 6: Filter room yang belum digunakan oleh user
    $usedRoomIds = array_column($usedRooms, 'room_id');

    $finalRecommendations = array_filter($recommendations, function ($recommendation) use ($usedRoomIds) {
        return !in_array($recommendation['room_id'], $usedRoomIds);
    });

    // Step 7: Simpan rekomendasi ke tabel rekom_rooms
    foreach ($finalRecommendations as $recommendation) {
        $db->table('rekom_rooms')->insert([
            'user_id' => $userId,
            'room_id' => $recommendation['room_id']
        ]);
    }

    // Step 8: Ambil data rekomendasi untuk ditampilkan
    $storedRecommendations = $db->table('rekom_rooms')
        ->select('rooms.*, ratings.rating')
        ->join('rooms', 'rekom_rooms.room_id = rooms.id')
        ->join('ratings', 'ratings.room_id = rooms.id', 'left')
        ->where('rekom_rooms.user_id', $userId)
        ->get()
        ->getResultArray();

    return view('explore', ['recommendedRooms' => $storedRecommendations]);
}
}
