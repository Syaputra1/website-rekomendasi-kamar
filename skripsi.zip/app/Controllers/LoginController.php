<?php

// app/Controllers/LoginController.php
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;

class LoginController extends Controller
{
    public function login()
    {
        // Validasi input
        if (!$this->validate([
            'username' => 'required',
            'password' => 'required|min_length[6]',
        ])) {
            return redirect()->to('/login')->withInput()->with('errors', $this->validator->getErrors());
        }

        // Proses login
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');
        $userModel = new UserModel();
        $user = $userModel->where('username', $username)->first();

        if ($user && password_verify($password, $user['password'])) {
            // Set session setelah login sukses
            session()->set([
                'user_id' => $user['id'],
                'username' => $user['username'],
                'role' => $user['role'],  // Menyimpan role pengguna
                'is_logged_in' => true
            ]);

            // Redirect berdasarkan role
            if ($user['role'] === 'Admin') {
                return redirect()->to('/dashboard');  // Redirect ke halaman admin
            } else {
                return redirect()->to('/');  // Redirect ke halaman utama untuk user biasa
            }
        } else {
            return redirect()->to('/login')->with('error', 'Username atau password salah');
        }
    }

    // Fungsi logout
    public function logout()
    {
        // Hapus session untuk logout
        session()->destroy();

        // Redirect ke halaman login setelah logout
        return redirect()->to('/login');
    }
}
