<?php
// app/Controllers/RatingController.php
namespace App\Controllers;

use App\Models\RatingModel;
use App\Models\RoomModel;
use App\Models\UserModel;

class RatingController extends BaseController
{
    protected $ratingModel;
    protected $roomModel;
    protected $userModel;

    public function __construct()
    {
        $this->ratingModel = new RatingModel();
        $this->roomModel = new RoomModel();
        $this->userModel = new UserModel();
    }

    // Menampilkan daftar rating
    public function index()
    {
        $data['ratings'] = $this->ratingModel->findAll();
        return view('rating/index', $data);
    }

    public function index2()
    {
        $data['rooms'] = $this->roomModel->findAll();
        return view('rating', $data);
    }

    // Menampilkan form untuk memberi rating
    public function create()
    {
        $data['rooms'] = $this->roomModel->findAll();
        return view('rating/create', $data);
    }

    // Menyimpan rating baru
    public function store()
    {
        $this->ratingModel->save([
            'user_id' => session()->get('user_id'), // Gunakan session untuk mendapatkan user yang login
            'room_id' => $this->request->getPost('room_id'),
            'rating' => $this->request->getPost('rating'),
            'review' => $this->request->getPost('review')
        ]);

        return redirect()->to('/rating');
    }

    // Menampilkan form untuk mengedit rating
    public function edit($id)
    {
        $data['rating'] = $this->ratingModel->find($id);
        $data['rooms'] = $this->roomModel->findAll();
        return view('rating/edit', $data);
    }

    // Menyimpan perubahan rating
    public function update($id)
    {
        $this->ratingModel->update($id, [
            'rating' => $this->request->getPost('rating'),
            'review' => $this->request->getPost('review')
        ]);

        return redirect()->to('/rating');
    }

    // Menghapus rating
    public function delete($id)
    {
        $this->ratingModel->delete($id);
        return redirect()->to('/rating');
    }


    public function submit_rating()
{
    $room_id = $this->request->getPost('room_id');
    $sudah_sewa = $this->request->getPost('sudah_sewa');
    $mau_sewa = $this->request->getPost('mau_sewa');
    $rating = $this->request->getPost('rating');

    // Validate inputs
    if ($rating < 1 || $rating > 5) {
        return redirect()->back()->with('error', 'Invalid rating value.');
    }

    $data = [
        'room_id' => $room_id,
        'user_id' => session()->get('user_id'),
        'sudah_sewa' => $sudah_sewa,
        'mau_sewa' => $mau_sewa,
        'rating' => $rating,
        // 'feedback' => $feedback,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s'),
    ];

    $ratingModel = new RatingModel(); // Replace with your actual model
    $ratingModel->insert($data);

    return redirect()->to('/room/details/' . $room_id)->with('success', 'Rating submitted successfully.');
}

}
