<?php

// app/Controllers/RoomController.php
namespace App\Controllers;

use App\Models\RoomModel;

class RoomController extends BaseController
{
    protected $roomModel;

    public function __construct()
    {
        $this->roomModel = new RoomModel();
    }

    // Menampilkan daftar kamar
    public function index()
    {
        $data['rooms'] = $this->roomModel->findAll();
        return view('room/index', $data);
    }

    // Menampilkan form untuk menambah kamar
    public function create()
    {
        return view('room/create');
    }

    public function store()
    {
        // Handle image upload
        $image = $this->request->getFile('image');
        $imageName = '';
    
        // Check if an image is uploaded
        if ($image->isValid() && !$image->hasMoved()) {
            // Generate a new name for the image
            $imageName = $image->getRandomName();
            // Move the image to the 'uploads' directory
            $image->move(ROOTPATH . 'public/uploads', $imageName);
        }
    
        // Process the price field
        $price = $this->request->getPost('price');
        $price = str_replace('.', '', $price); // Remove periods (thousands separators)
        $price = str_replace(',', '.', $price); // Replace commas with dots for decimal
    
        // Convert the price to float or integer
        $price = (float) $price; // Ensures the value is a proper number for storage
    
        // Save the room data along with the image name
        $this->roomModel->save([
            'name' => $this->request->getPost('name'),
            'price' => $price,  // Store the processed price as a number
            'type' => $this->request->getPost('type'),
            'image' => $imageName,  // Store the image name in the database
        ]);
    
        return redirect()->to('/room');
    }
    


    // Menampilkan form untuk mengedit kamar
    public function edit($id)
    {
        $data['room'] = $this->roomModel->find($id);
        return view('room/edit', $data);
    }

    // Menyimpan perubahan kamar
    public function update($id)
    {
        $room = $this->roomModel->find($id); // Fetch the room data by ID
    
        // Handle image upload
        $image = $this->request->getFile('image');
        $imageName = $room['image']; // Default to the existing image name if no new image is uploaded
    
        // Check if a new image is uploaded
        if ($image->isValid() && !$image->hasMoved()) {
            // If a new image is uploaded, move it to the 'uploads' folder
            $imageName = $image->getRandomName();
            $image->move(ROOTPATH . 'public/uploads', $imageName);
        }
    
        // Process the price field
        $price = $this->request->getPost('price');
        $price = str_replace('.', '', $price); // Remove periods (thousands separators)
        $price = str_replace(',', '.', $price); // Replace commas with dots for decimal
    
        // Convert the price to float
        $price = (float) $price; // Ensure the price is a valid number
    
        // Update the room data
        $this->roomModel->update($id, [
            'name' => $this->request->getPost('name'),
            'price' => $price,
            'type' => $this->request->getPost('type'),
            'image' => $imageName,  // Store the image name in the database (existing image if no new one is uploaded)
        ]);
    
        return redirect()->to('/room');
    }
    

    // Menghapus kamar
    public function delete($id)
    {
        $this->roomModel->delete($id);
        return redirect()->to('/room');
    }

    public function details($id)
    {
        // Fetch the room details by ID
        $room = $this->roomModel->find($id);

        if (!$room) {
            // If no room is found, show a 404 error
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Room not found');
        }

        // Pass the room data to the view
        return view('room_details', ['room' => $room]);
    }
}
