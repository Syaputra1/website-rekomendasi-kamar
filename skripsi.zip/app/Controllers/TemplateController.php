<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class TemplateController extends Controller
{
    public function index()
    {
        return view('dashboard/index'); // view untuk halaman home
    }
}
