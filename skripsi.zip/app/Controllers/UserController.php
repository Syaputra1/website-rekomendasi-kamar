<?php

// app/Controllers/UserController.php
namespace App\Controllers;

use App\Models\UserModel;

class UserController extends BaseController
{
    protected $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    // Menampilkan daftar pengguna
    public function index()
    {
        $data['users'] = $this->userModel->findAll();
        return view('user/index', $data);
    }

    // Menampilkan form untuk menambah pengguna
    public function create()
    {
        return view('user/create');
    }

    // Menyimpan pengguna baru
    public function store()
    {
        $this->userModel->save([
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'jenis_kelamin' => $this->request->getPost('gender'),
            'umur' => $this->request->getPost('age'),
            'status' => $this->request->getPost('job'),
            'role' => $this->request->getPost('role'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
        ]);

        return redirect()->to('/user');
    }

    // Menampilkan form untuk mengedit pengguna
    public function edit($id)
    {
        $data['user'] = $this->userModel->find($id);
        return view('user/edit', $data);
    }

    // Menyimpan perubahan pengguna
    public function update($id)
    {
        $this->userModel->update($id, [
      'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'jenis_kelamin' => $this->request->getPost('gender'),
            'umur' => $this->request->getPost('age'),
            'status' => $this->request->getPost('job'),
            'role' => $this->request->getPost('role'),
        ]);

        return redirect()->to('/user');
    }

    // Menghapus pengguna
    public function delete($id)
    {
        $this->userModel->delete($id);
        return redirect()->to('/user');
    }
}
