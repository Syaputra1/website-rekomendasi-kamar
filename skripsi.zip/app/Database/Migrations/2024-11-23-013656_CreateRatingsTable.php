<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateRatingsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'user_id' => [
                'type'       => 'INT',
                'unsigned'   => true,
            ],
            'room_id' => [
                'type'       => 'INT',
                'unsigned'   => true,
            ],
            'sudah_sewa' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'mau_sewa' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'rating' => [
                'type'       => 'TINYINT',
                'constraint' => 1, // Rating 1-5
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true); // Primary key
        $this->forge->addForeignKey('user_id', 'users', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('room_id', 'rooms', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('ratings'); // Nama tabel
    }

    public function down()
    {
        $this->forge->dropTable('ratings');
    }
}
