<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;
use CodeIgniter\I18n\Time;

class UserSeeder extends Seeder
{
    public function run()
    {
        // Prepare the data to be seeded
        $data = [
            [
                'username'       => 'admin',
                'status'         => 'Active',
                'umur'           => '30',
                'jenis_kelamin'  => 'Male',
                'alamat'         => 'Jl. Admin No. 1',
                'email'          => 'admin@example.com',
                'password'       => password_hash('admin1234', PASSWORD_DEFAULT), // Ensure this is securely hashed
                'role'           => 'Admin',
                'created_at'     => Time::now(),
                'updated_at'     => Time::now(),
            ]
        ];

        // Insert data into the users table
        $this->db->table('users')->insertBatch($data);
    }
}
