<?php

// app/Models/RatingModel.php
namespace App\Models;

use CodeIgniter\Model;

class RatingModel extends Model
{
    protected $table      = 'ratings';  // Ganti dengan nama tabel yang sesuai
    protected $primaryKey = 'id';
     // Allow all necessary fields to be mass-assigned
     protected $allowedFields = [
        'user_id',
        'room_id',
        'sudah_sewa',
        'mau_sewa',
        'rating',
        'feedback',
        'created_at',
        'updated_at',
    ];
    protected $useTimestamps = true;
}

