<?php

namespace App\Models;

use CodeIgniter\Model;

class RecommendationModel extends Model
{
    protected $table = 'ratings';

    public function getRecommendations($userId)
    {
        $ratings = $this->db->table($this->table)->get()->getResultArray();

        // Step 1: Organize ratings into a matrix
        $matrix = [];
        foreach ($ratings as $rating) {
            $matrix[$rating['user_id']][$rating['room_id']] = $rating['rating'];
        }

        // Step 2: Calculate similarity between users
        $similarities = [];
        foreach ($matrix as $otherUserId => $otherRatings) {
            if ($otherUserId != $userId) {
                $similarities[$otherUserId] = $this->cosineSimilarity($matrix[$userId], $otherRatings);
            }
        }

        // Step 3: Predict ratings for unseen rooms
        $predictions = [];
        foreach ($matrix as $otherUserId => $otherRatings) {
            foreach ($otherRatings as $roomId => $rating) {
                if (!isset($matrix[$userId][$roomId])) {
                    if (!isset($predictions[$roomId])) {
                        $predictions[$roomId] = 0;
                    }
                    $predictions[$roomId] += $rating * $similarities[$otherUserId];
                }
            }
        }

        // Step 4: Sort predictions by score
        arsort($predictions);

        // Fetch room details for the top recommendations
        $recommendedRooms = [];
        foreach (array_keys($predictions) as $roomId) {
            $room = $this->db->table('rooms')->where('id', $roomId)->get()->getRowArray();
            $recommendedRooms[] = $room;
        }

        return $recommendedRooms;
    }

    private function cosineSimilarity($userRatings, $otherRatings)
    {
        $dotProduct = 0;
        $userMagnitude = 0;
        $otherMagnitude = 0;

        foreach ($userRatings as $roomId => $rating) {
            $dotProduct += $rating * ($otherRatings[$roomId] ?? 0);
            $userMagnitude += pow($rating, 2);
            $otherMagnitude += pow(($otherRatings[$roomId] ?? 0), 2);
        }

        return ($dotProduct / (sqrt($userMagnitude) * sqrt($otherMagnitude))) ?: 0;
    }

    public function saveRecommendations($userId, $recommendedRooms)
    {
        // // Step 1: Hapus semua data rekomendasi lama untuk user tertentu
        // $this->db->table('rekom_rooms')->where('user_id', $userId)->truncate();
    
        // Step 2: Tambahkan rekomendasi baru ke tabel
        foreach ($recommendedRooms as $room) {
            $data = [
                'user_id' => $userId,
                'room_id' => $room['id'],
            ];
dd($data);
            $this->db->table('rekom_rooms')->insert($data);
    
            // Debugging: Tampilkan data yang disimpan ke tabel
            log_message('info', 'Data rekomendasi disimpan: ' . json_encode($data));
        }
    }
    
}
