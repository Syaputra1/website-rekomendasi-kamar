<?= $this->extend('templates/index'); ?>
<?= $this->section('content'); ?>

<!-- Include Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

<div class="container mt-4">
    <h1>Dashboard</h1>
    <p>Welcome, <?= session()->get('username'); ?>!</p>

    <div class="row mt-4">
        <!-- Card for Total Items -->
        <!-- <div class="col-md-4">
            <div class="card bg-primary mb-4 card-hover">
                <div class="card-body text-white">
                <i class="fas fa-box-open"></i> Total Items
                    <h5 class="card-title"></h5>
                    <p class="card-text">Total number of items in stock.</p>
                </div>
            </div>
        </div> -->
        
        <!-- Card for Total Users -->
        <!-- <div class="col-md-4">
            <div class="card bg-success mb-4 card-hover">
                <div class="card-body text-white">
                <i class="fas fa-users"></i> Total Users
                    <h5 class="card-title"></h5>
                    <p class="card-text">Total registered users in the system.</p>
                </div>
            </div>
        </div> -->

        <!-- Card for Total Sales -->
        <!-- <div class="col-md-4">
            <div class="card bg-info mb-4 card-hover">
                <div class="card-body text-white">
                <i class="fas fa-chart-line"></i> Total Sales
                    <h5 class="card-title"></h5>
                    <p class="card-text">Total sales made this month.</p>
                </div>
            </div>
        </div> -->
    </div>
</div>

<style>
.card-hover {
    transition: transform 0.2s; /* Smooth transition */
}

.card-hover:hover {
    transform: scale(1.05); /* Slightly enlarge the card on hover */
    cursor: pointer; /* Change cursor to pointer */
}
</style>

<?= $this->endSection(); ?>
