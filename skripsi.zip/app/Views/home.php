<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .navbar-brand img {
            margin-right: 10px;
            width: 40px;
            height: auto;
        }

        .hero {
            position: relative;
            background: url('/img/img1.jpg') no-repeat center center/cover;
            min-height: 100vh;
            color: #fff;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
        }

        .hero-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1;
        }

        .hero-content {
            z-index: 2;
        }

        .hero h1 {
            font-size: 3rem;
            font-weight: bold;
        }

        .explore-btn {
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 1.2rem;
        }

        .rooms-section {
            position: relative;
            background: url('/img/img1.jpg') no-repeat center center/cover;
            min-height: 100vh;
            color: #fff;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
        }


        .card {
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
        }

        footer {
            background: #343a40;
            color: #fff;
            text-align: center;
            padding: 15px 0;
        }

        .star-rating {
            color: gold;
            font-size: 1rem;
            display: inline-block;
        }

        .carousel {
            margin: 0 auto;
            max-width: 80%;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="<?= site_url('/') ?>">
                <img src="/img/logo.png" alt="Logo">
                Grand Kamala Lagoon
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="<?= site_url('/') ?>">Home</a></li>
                    <?php if (session()->get('is_logged_in')) : ?>
                        <li class="nav-item"><a class="nav-link" href="<?= site_url('/index2') ?>">Rating</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?= site_url('/logout') ?>">Logout</a></li>
                    <?php else : ?>
                        <li class="nav-item"><a class="nav-link" href="<?= site_url('/login') ?>">Login</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero">
        <div class="hero-overlay"></div>
        <div class="hero-content">
            <h1>Rekomendasi Apartemen</h1>
            <p class="lead">Temukan apartemen terbaik di Grand Kamala Lagoon.</p>
            <a href="<?= site_url('/explore') ?>" class="btn btn-primary explore-btn">Explore</a>
        </div>
    </div>

    <!-- Rooms Section -->
    <div class="rooms-section">
        <div class="container">
        <div class="hero-overlay"></div>
            <div id="roomsCarousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <?php foreach (array_chunk($rooms, 4) as $index => $roomChunk): ?>
                        <div class="carousel-item <?= $index === 0 ? 'active' : '' ?>">
                            <div class="row justify-content-center">
                                <?php foreach ($roomChunk as $room): ?>
                                    <div class="col-md-3 col-sm-6 mb-4">
                                        <div class="card">
                                            <img src="<?= base_url($room['image'] ? 'uploads/' . $room['image'] : 'no-image-available.png') ?>" class="card-img-top" alt="Room Image" style="height: 150px; object-fit: cover;">
                                            <div class="card-body p-2">
                                                <h6 class="card-title text-truncate"><?= $room['name'] ?></h6>
                                                <p class="card-text mb-1"><strong>Type:</strong> <?= $room['type'] ?></p>
                                                <p class="card-text mb-2"><strong>Price:</strong> Rp <?= number_format($room['price'], 0, ',', '.') ?></p>
                                                <p class="card-text mb-2">
                                                    <strong>Rating:</strong>
                                                    <span class="star-rating">
                                                        <?= str_repeat('★', floor($room['rating'])) ?>
                                                        <?= str_repeat('☆', 5 - floor($room['rating'])) ?>
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#roomsCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#roomsCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; <?= date('Y') ?> Grand Kamala Lagoon. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
