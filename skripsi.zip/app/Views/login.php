<!-- app/Views/login.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        /* Styling untuk background hero */
        .hero {
            position: relative;
            background: url('/img/img1.jpg') no-repeat center center/cover;
            height: 100vh;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .hero-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.4); /* Efek overlay */
            z-index: 1;
        }

        .hero-content {
            position: relative;
            z-index: 2;
            text-align: center;
            max-width: 400px;
            width: 100%;
            padding: 30px;
            background: rgba(0, 0, 0, 0.6);
            border-radius: 10px;
        }

        .hero h2 {
            margin-bottom: 20px;
            font-size: 2.5rem;
        }

        .form-label {
            font-weight: bold;
        }

        .form-control {
            border-radius: 30px;
        }

        .btn-primary {
            width: 100%;
            border-radius: 30px;
            padding: 10px;
        }

        .login-footer {
            margin-top: 15px;
            color: #fff;
        }

        .login-footer a {
            color: #fff;
            text-decoration: none;
        }

        .login-footer a:hover {
            text-decoration: underline;
        }
        footer {
            background: #343a40;
            color: #fff;
            text-align: center;
            padding: 15px 0;
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .hero h2 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>

    <div class="hero">
        <div class="hero-overlay"></div>

        <div class="hero-content">
            <h2>Login</h2>
            <form action="/login" method="POST">
                <!-- username input -->
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                
                <!-- Password input -->
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>

                <!-- Login button -->
                <button type="submit" class="btn btn-primary">Login</button>
            </form>

            <!-- Register link -->
            <div class="login-footer">
                <p>Belum punya akun? <a href="<?= site_url('/register') ?>">Daftar sekarang</a></p>
            </div>
        </div>
    </div>
   <!-- Footer -->
   <footer>
        <p>&copy; <?= date('Y') ?> Grand Kamala Lagoon. All rights reserved.</p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
