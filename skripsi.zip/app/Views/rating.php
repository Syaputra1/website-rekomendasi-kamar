<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rating</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        /* Tambahkan styling tambahan di sini */
        .hero {
            position: relative;
            background: url('/img/img1.jpg') no-repeat center center/cover;
            height: 100vh;
            color: #fff;
        }

        .hero-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            /* Efek overlay */
        }

        .hero-content {
            position: relative;
            z-index: 2;
            text-align: center;
            top: 50%;
            transform: translateY(-50%);
        }

        .explore-btn {
            margin-top: 20px;
        }

        .recommendation-box {
            background: rgba(255, 255, 255, 0.8);
            padding: 15px;
            border-radius: 10px;
            text-align: center;
        }

        .recommendation-box img {
            width: 100%;
            border-radius: 10px;
        }

        /* Logo styling */
        .hero-logo {
            width: 50px; /* Adjust the size as per your requirement */
            height: auto;
            object-fit: contain;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
<!-- app/Views/navbar.php (atau bagian navbar di login.php dan register.php) -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <img src="/img/logo.png" alt="Logo" class="hero-logo">
        <a class="navbar-brand" href="<?= site_url('/') ?>">Grand Kamala Lagoon</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('/') ?>">Home</a>
                </li>
                <!-- Menampilkan tombol Login atau Logout berdasarkan session -->
                <?php if (session()->get('is_logged_in')) : ?>
                            <!-- Jika sudah login, tampilkan tombol Logout -->
                            <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('/index2') ?>">Rating</a>
                </li>
                    <!-- Jika sudah login, tampilkan tombol Logout -->
                    <li class="nav-item">
                        <a class="nav-link" href="<?= site_url('/logout') ?>">Logout</a>
                    </li>
                <?php else : ?>
                    <!-- Jika belum login, tampilkan tombol Login -->
                    <li class="nav-item">
                        <a class="nav-link" href="<?= site_url('/login') ?>">Login</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<div class="container my-5">
    <h2 class="mb-4">Rooms</h2>
    <div class="row">
        <?php foreach ($rooms as $room): ?>
            <div class="col-md-3 col-sm-6 mb-4"> <!-- Smaller columns for compact layout -->
                <div class="card" style="width: 100%; height: 350px; overflow: hidden;"> <!-- Compact height -->
                    <!-- Room Image -->
                    <?php if ($room['image']): ?>
                        <img src="<?= base_url('uploads/' . $room['image']) ?>" class="card-img-top" alt="Room Image" style="height: 150px; object-fit: cover;">
                    <?php else: ?>
                        <img src="<?= base_url('no-image-available.png') ?>" class="card-img-top" alt="No Image" style="height: 150px; object-fit: cover;">
                    <?php endif; ?>

                    <div class="card-body p-2"> <!-- Compact padding -->
                        <!-- Room Name -->
                        <h6 class="card-title text-truncate"><?= $room['name'] ?></h6> <!-- Truncate long names -->

                        <!-- Room Type -->
                        <p class="card-text mb-1" style="font-size: 0.9rem;"><strong>Type:</strong> <?= $room['type'] ?></p>
                        
                        <!-- Room Price -->
                        <p class="card-text mb-2" style="font-size: 0.9rem;"><strong>Price:</strong> Rp <?= number_format($room['price'], 0, ',', '.') ?></p>
                        
                        <!-- More Details Button -->
                        <a href="<?= site_url('room/details/' . $room['id']) ?>" class="btn btn-primary btn-sm">View Details</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
