<?= $this->extend('templates/index'); ?>
<?= $this->section('content'); ?>

<div class="container mt-4">
    <h1>Data Rekomendasi Kamar</h1>

    <table id="barangTable" class="table table-striped table-bordered">
        <thead>
        <tr>
        <th>No</th>
    <th>Nama Kamar</th>
    <th>Type</th>
    <th>Harga</th>
    <th>Foto</th>
</tr>
</thead>
<tbody>
<?php $no = 1; ?>
<?php foreach ($rooms as $room): ?>
    <tr>
    <td><?= $no++; ?></td>
        <td><?= $room['name'] ?></td>
        <td><?= $room['type'] ?></td>
        <td>Rp <?= number_format($room['price'], 0, ',', '.') ?></td>
        <td>
            <!-- Display the image if it exists -->
            <?php if ($room['image']): ?>
                <img src="<?= base_url('uploads/' . $room['image']) ?>" alt="Room Image" width="100" height="100">
            <?php else: ?>
                <span>No Image</span>
            <?php endif; ?>
        </td>
    </tr>
<?php endforeach; ?>
</tbody>
    </table>
</div>

<!-- Include jQuery and DataTables scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        $('#barangTable').DataTable({
            "paging": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "lengthChange": true,
            "pageLength": 10,
            "language": {
                "search": "Search Items:",
                "lengthMenu": "Show _MENU_ items per page",
                "info": "Showing page _PAGE_ of _PAGES_",
                "infoEmpty": "No items available",
                "zeroRecords": "No matching items found"
            }
        });
    });
</script>

<?= $this->endSection(); ?>
