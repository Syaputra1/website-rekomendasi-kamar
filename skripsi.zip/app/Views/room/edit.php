<?= $this->extend('templates/index'); ?>
<?= $this->section('content'); ?>

<div class="container mt-4">
    <div class="card shadow-sm">
        <div class="card-header bg-success text-white">
            <h2 class="text-center mb-0">Form Edit Kamar</h2>
        </div>
        <div class="card-body">
            <!-- Form to update the room -->
            <form action="<?= base_url('room/update/' . $room['id']); ?>" method="post" enctype="multipart/form-data">
                <!-- CSRF Token for security -->
                <?= csrf_field(); ?>

                <div class="form-group">
                    <label for="name">Nama Kamar</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?= old('name', $room['name']); ?>" required placeholder="Enter room name">
                </div>

                <div class="form-group">
                    <label for="price">Harga</label>
                    <input type="text" class="form-control" id="price" name="price" value="<?= old('price', $room['price']); ?>" required placeholder="Enter price" onkeyup="formatRupiah(this)">
                </div>

                <div class="form-group">
                    <label for="type">Type Kamar</label>
                    <input type="text" class="form-control" id="type" name="type" value="<?= old('type', $room['type']); ?>" required placeholder="Enter room type">
                </div>

                <div class="form-group">
                    <label for="image">Upload Gambar</label>
                    <input type="file" class="form-control" id="image" name="image">
                    <!-- Display current image if available -->
                    <?php if ($room['image']): ?>
                        <p><strong>Current Image:</strong></p>
                        <img src="<?= base_url('uploads/' . $room['image']) ?>" alt="Room Image" width="100" height="100">
                    <?php endif; ?>
                </div>

                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn btn-success">Update Room</button>
                    <a href="<?= base_url('room'); ?>" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function formatRupiah(angka) {
    var number_string = angka.value.replace(/[^,\d]/g, '').toString(),
        split = number_string.split(','),
        sisa = split[0].length % 3,
        rupiah = split[0].substr(0, sisa),
        ribuan = split[0].substr(sisa).match(/\d{3}/gi);
    
    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }

    angka.value = rupiah + (split[1] ? ',' + split[1] : '');
}
</script>

<?= $this->endSection(); ?>
