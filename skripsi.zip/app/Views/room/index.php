<?= $this->extend('templates/index'); ?>
<?= $this->section('content'); ?>

<div class="container mt-4">
    <h1>Data Kamar</h1>
    <a href="<?= base_url('room/create'); ?>" class="btn btn-primary mb-3">Add New Room</a>
    <button id="downloadExcel" class="btn btn-success mb-3">Download Excel</button>

    <table id="barangTable" class="table table-striped table-bordered">
        <thead>
        <tr>
            <th>No</th>
            <th>Nama Kamar</th>
            <th>Type</th>
            <th>Harga</th>
            <th>Foto</th>
            <th>Aksi</th>
        </tr>
        </thead>
        <tbody>
        <?php $no = 1; ?>
        <?php foreach ($rooms as $room): ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $room['name'] ?></td>
                <td><?= $room['type'] ?></td>
                <td>Rp <?= number_format($room['price'], 0, ',', '.') ?></td>
                <td>
                    <?php if ($room['image']): ?>
                        <img src="<?= base_url('uploads/' . $room['image']) ?>" alt="Room Image" width="100" height="100">
                    <?php else: ?>
                        <span>No Image</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="/room/edit/<?= $room['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="/room/delete/<?= $room['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin?')">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Include jQuery, DataTables, and SheetJS scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/xlsx/dist/xlsx.full.min.js"></script>
<script>
    $(document).ready(function() {
        $('#barangTable').DataTable({
            "paging": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "lengthChange": true,
            "pageLength": 10,
            "language": {
                "search": "Search Items:",
                "lengthMenu": "Show _MENU_ items per page",
                "info": "Showing page _PAGE_ of _PAGES_",
                "infoEmpty": "No items available",
                "zeroRecords": "No matching items found"
            }
        });

        // Download Excel logic
        $('#downloadExcel').click(function() {
            var tableData = [];
            var headers = [];
            // Get table headers
            $('#barangTable thead tr th').each(function() {
                headers.push($(this).text());
            });
            tableData.push(headers);

            // Get table rows
            $('#barangTable tbody tr').each(function() {
                var rowData = [];
                $(this).find('td').each(function(index) {
                    if (index === 5) { // Include image URL
                        var img = $(this).find('img');
                        if (img.length > 0) {
                            rowData.push(img.attr('src')); // Add image URL
                        } else {
                            rowData.push("No Image");
                        }
                    } else {
                        rowData.push($(this).text().trim());
                    }
                });
                tableData.push(rowData);
            });

            // Convert data to Excel
            var ws = XLSX.utils.aoa_to_sheet(tableData);
            var wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, "Data Kamar");
            XLSX.writeFile(wb, "Data_Kamar.xlsx");
        });
    });
</script>

<?= $this->endSection(); ?>
