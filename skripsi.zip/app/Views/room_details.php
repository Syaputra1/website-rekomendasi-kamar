<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room Details</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="<?= site_url('/') ?>">Grand Kamala Lagoon</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= site_url('/') ?>">Home</a>
                    </li>
                    <?php if (session()->get('is_logged_in')) : ?>
                        <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('/index2') ?>">Rating</a>
                </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= site_url('/logout') ?>">Logout</a>
                        </li>
                    <?php else : ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= site_url('/login') ?>">Login</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Room Details -->
    <div class="container my-5">
        <h1 class="mb-4">Room Details</h1>
        <div class="row">
            <div class="col-md-6">
                <img src="<?= $room['image'] ? base_url('uploads/' . $room['image']) : base_url('no-image-available.png') ?>" 
                     class="img-fluid rounded" alt="Room Image">
            </div>
            <div class="col-md-6">
                <h3><?= $room['name'] ?></h3>
                <p><strong>Type:</strong> <?= $room['type'] ?></p>
                <p><strong>Price:</strong> Rp <?= number_format($room['price'], 0, ',', '.') ?></p>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#ratingModal">Give Rating</button>
            </div>
        </div>
    </div>

   <!-- Rating Modal -->
<div class="modal fade" id="ratingModal" tabindex="-1" aria-labelledby="ratingModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ratingModalLabel">Rate the Room</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="ratingForm" action="<?= site_url('rating/submit_rating') ?>" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="room_id" value="<?= $room['id'] ?>">

                    <!-- Dropdown: Already Rented -->
                    <div class="mb-3">
                        <label for="sudah_sewa" class="form-label">Already Rented?</label>
                        <select name="sudah_sewa" id="sudah_sewa" class="form-select" required>
                            <option value="" disabled selected>Select an option</option>
                            <option value="yes">Yes</option>
                            <option value="no">No</option>
                        </select>
                    </div>

                    <!-- Dropdown: Will Rent (conditional on 'No') -->
                    <div class="mb-3" id="willRentContainer" style="display: none;">
                        <label for="mau_sewa" class="form-label">Will You Rent?</label>
                        <select name="mau_sewa" id="mau_sewa" class="form-select">
                            <option value="" disabled selected>Select an option</option>
                            <option value="yes">Yes</option>
                            <option value="no">No</option>
                        </select>
                    </div>

                    <!-- Rating Field -->
                    <div class="mb-3">
                        <label for="rating" class="form-label">Rating (1-5):</label>
                        <input type="number" name="rating" id="rating" class="form-control" min="1" max="5" required>
                    </div>

                    <!-- Feedback Field -->
                    <!-- <div class="mb-3">
                        <label for="feedback" class="form-label">Feedback:</label>
                        <textarea name="feedback" id="feedback" class="form-control" rows="3"></textarea>
                    </div> -->
                </div>

                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.getElementById('sudah_sewa').addEventListener('change', function () {
        const willRentContainer = document.getElementById('willRentContainer');
        if (this.value === 'no') {
            willRentContainer.style.display = 'block';
        } else {
            willRentContainer.style.display = 'none';
        }
    });
</script>

</body>

</html>
