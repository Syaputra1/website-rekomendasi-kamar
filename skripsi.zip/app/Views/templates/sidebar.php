<?php 

use App\Models\UserModel;

$userModel = new UserModel();
$user = $userModel->find(session()->get('user_id'));

?>

<!-- Sidebar Admin -->
<ul class="navbar-nav bg-gradient-secondary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/dashboard">
        <img src="/img/logo.png" alt="logo" style="width: 35%;">
        <div class="sidebar-brand-text mx-3">Grand <sup>Kamala Lagoon</sup></div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider">
    <li class="nav-item">
        <a class="nav-link" href="/dashboard">
            <i class="fas fa-fw fa-laptop"></i>
            <span>Dashboard</span>
        </a>
    </li>
    <!-- Nav Item - User (only for admin role) -->
    <?php if ($user && (is_array($user) ? $user['role'] === 'Admin' : $user->role === 'Admin')) : ?>
    <li class="nav-item">
        <a class="nav-link" href="/user">
            <i class="fas fa-fw fa-user"></i>
            <span>User</span>
        </a>
    </li>
    <!-- <li class="nav-item">
        <a class="nav-link" href="/pelanggan">
        <i class="fas fa-users"></i>
            <span>Pelanggan</span>
        </a>
    </li> -->
    <?php endif; ?>

    <!-- Nav Item - Barang -->
    <li class="nav-item">
        <a class="nav-link" href="/room">
            <i class="fas fa-fw fa-box"></i>
            <span>Rooms</span>
        </a>
    </li>

    <!-- Nav Item - Transaksi -->
    <li class="nav-item">
        <a class="nav-link" href="/rekom_rooms">
            <i class="fas fa-fw fa-chart-line"></i>
            <span>Rating</span>
        </a>
    </li>

    <!-- Nav Item - Logout -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('logout'); ?>">
            <i class="fas fa-fw fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>
<!-- End of Sidebar Admin-->
