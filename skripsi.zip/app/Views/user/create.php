<?= $this->extend('templates/index'); ?>
<?= $this->section('content'); ?>

<div class="container mt-4">
    <div class="card shadow-sm">
        <div class="card-header bg-success text-white">
            <h2 class="text-center mb-0">Form Tambah User</h2>
        </div>
        <div class="card-body">
            <form action="<?= base_url('user/store'); ?>" method="post" class="p-4">
                <?= csrf_field(); ?>
                <div class="row">
                    <!-- Username input (left column) -->
                    <div class="col-md-6 mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control <?= session('errors.username') ? 'is-invalid' : ''; ?>" id="username" name="username" value="<?= old('username') ?>" required>
                        <div class="invalid-feedback">
                            <?= session('errors.username'); ?>
                        </div>
                    </div>

                    <!-- Email input (right column) -->
                    <div class="col-md-6 mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control <?= session('errors.email') ? 'is-invalid' : ''; ?>" id="email" name="email" value="<?= old('email') ?>" required>
                        <div class="invalid-feedback">
                            <?= session('errors.email'); ?>
                        </div>
                    </div>

                    <!-- Password input (left column) -->
                    <div class="col-md-6 mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control <?= session('errors.password') ? 'is-invalid' : ''; ?>" id="password" name="password" required>
                        <div class="invalid-feedback">
                            <?= session('errors.password'); ?>
                        </div>
                    </div>

                    <!-- Confirm Password input (right column) -->
                    <div class="col-md-6 mb-3">
                        <label for="confirm_password" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control <?= session('errors.confirm_password') ? 'is-invalid' : ''; ?>" id="confirm_password" name="confirm_password" required>
                        <div class="invalid-feedback">
                            <?= session('errors.confirm_password'); ?>
                        </div>
                    </div>

                    <!-- Gender dropdown (left column) -->
                    <div class="col-md-6 mb-3">
                        <label for="gender" class="form-label">Jenis Kelamin</label>
                        <select class="form-control <?= session('errors.gender') ? 'is-invalid' : ''; ?>" id="gender" name="gender" required>
                            <option value="" disabled selected>Pilih Jenis Kelamin</option>
                            <option value="Male" <?= old('gender') == 'Male' ? 'selected' : ''; ?>>Laki-laki</option>
                            <option value="Female" <?= old('gender') == 'Female' ? 'selected' : ''; ?>>Perempuan</option>
                        </select>
                        <div class="invalid-feedback">
                            <?= session('errors.gender'); ?>
                        </div>
                    </div>

                    <!-- Age input (right column) -->
                    <div class="col-md-6 mb-3">
                        <label for="age" class="form-label">Usia</label>
                        <input type="number" class="form-control <?= session('errors.age') ? 'is-invalid' : ''; ?>" id="age" name="age" value="<?= old('age') ?>" min="18" required>
                        <div class="invalid-feedback">
                            <?= session('errors.age'); ?>
                        </div>
                    </div>

                    <!-- Job input (left column) -->
                    <div class="col-md-6 mb-3">
                        <label for="job" class="form-label">Pekerjaan</label>
                        <input type="text" class="form-control <?= session('errors.job') ? 'is-invalid' : ''; ?>" id="job" name="job" value="<?= old('job') ?>" required>
                        <div class="invalid-feedback">
                            <?= session('errors.job'); ?>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                    <label for="role">Role</label>
                    <select class="form-control <?= session('errors.role') ? 'is-invalid' : ''; ?>" id="role" name="role" required>
                        <option value="" disabled selected>Select role</option>
                        <option value="Admin" <?= old('role') == 'Admin' ? 'selected' : ''; ?>>Admin</option>
                        <option value="User" <?= old('role') == 'User' ? 'selected' : ''; ?>>User</option>
                    </select>
                    <div class="invalid-feedback">
                        <?= session('errors.role'); ?>
                    </div>
                </div>
                </div>

                <!-- Role input -->
                

                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn btn-success">Add User</button>
                    <a href="<?= base_url('user'); ?>" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>
