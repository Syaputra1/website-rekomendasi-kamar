<?= $this->extend('templates/index'); ?>
<?= $this->section('content'); ?>

<div class="container mt-4">
    <div class="card shadow-sm">
        <div class="card-header bg-success text-white">
            <h2 class="text-center mb-0">Form Edit User</h2>
        </div>
        <div class="card-body">
            <form action="<?= base_url('user/update/' . $user['id']); ?>" method="post" class="p-4">
                <?= csrf_field(); ?>
                
                <div class="row">
                    <!-- Username input (left column) -->
                    <div class="col-md-6 mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control <?= session('errors.username') ? 'is-invalid' : ''; ?>" id="username" name="username" value="<?= old('username', $user['username']) ?>" required>
                        <div class="invalid-feedback">
                            <?= session('errors.username'); ?>
                        </div>
                    </div>

                    <!-- Email input (right column) -->
                    <div class="col-md-6 mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control <?= session('errors.email') ? 'is-invalid' : ''; ?>" id="email" name="email" value="<?= old('email', $user['email']) ?>" required>
                        <div class="invalid-feedback">
                            <?= session('errors.email'); ?>
                        </div>
                    </div>

                    <!-- Gender dropdown (left column) -->
                    <div class="col-md-6 mb-3">
                        <label for="gender" class="form-label">Jenis Kelamin</label>
                        <select class="form-control <?= session('errors.gender') ? 'is-invalid' : ''; ?>" id="gender" name="gender" required>
                            <option value="" disabled>Select Jenis Kelamin</option>
                            <option value="Male" <?= old('gender', $user['jenis_kelamin']) == 'Male' ? 'selected' : ''; ?>>Laki-laki</option>
                            <option value="Female" <?= old('gender', $user['jenis_kelamin']) == 'Female' ? 'selected' : ''; ?>>Perempuan</option>
                        </select>
                        <div class="invalid-feedback">
                            <?= session('errors.gender'); ?>
                        </div>
                    </div>

                    <!-- Age input (right column) -->
                    <div class="col-md-6 mb-3">
                        <label for="age" class="form-label">Usia</label>
                        <input type="number" class="form-control <?= session('errors.age') ? 'is-invalid' : ''; ?>" id="age" name="age" value="<?= old('age', $user['umur']) ?>"  required>
                        <div class="invalid-feedback">
                            <?= session('errors.age'); ?>
                        </div>
                    </div>

                    <!-- Job input (left column) -->
                    <div class="col-md-6 mb-3">
                        <label for="job" class="form-label">Pekerjaan</label>
                        <input type="text" class="form-control <?= session('errors.job') ? 'is-invalid' : ''; ?>" id="job" name="job" value="<?= old('job', $user['status']) ?>" required>
                        <div class="invalid-feedback">
                            <?= session('errors.job'); ?>
                        </div>
                    </div>

                       <!-- Role input -->
                <div class="col-md-6 mb-3">
                    <label for="role">Role</label>
                    <select class="form-control <?= session('errors.role') ? 'is-invalid' : ''; ?>" id="role" name="role" required>
                        <option value="" disabled>Select role</option>
                        <option value="Admin" <?= old('role', $user['role']) == 'Admin' ? 'selected' : ''; ?>>Admin</option>
                        <option value="User" <?= old('role', $user['role']) == 'User' ? 'selected' : ''; ?>>User</option>
                    </select>
                    <div class="invalid-feedback">
                        <?= session('errors.role'); ?>
                    </div>
                </div>
                </div>

             

                <div class="d-flex justify-content-between mt-4">
                    <button type="submit" class="btn btn-success">Update User</button>
                    <a href="<?= base_url('user'); ?>" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>
