<?= $this->extend('templates/index'); ?>
<?= $this->section('content'); ?>

<div class="container mt-4">
    <h1>User Management</h1>
    <a href="<?= base_url('user/create'); ?>" class="btn btn-primary mb-3">Add New User</a>
    <table id="userTable" class="table table-striped table-bordered">
        <thead>
        <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php $no = 1; ?>
        <?php foreach ($users as $user): ?>
            <tr>
            <td><?= $no++; ?></td>
                <td><?= $user['username'] ?></td>
                <td><?= $user['email'] ?></td>
                <td><?= ucfirst($user['role']) ?></td>
                <td>
                    <a href="/user/edit/<?= $user['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="/user/delete/<?= $user['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin?')">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Include jQuery and DataTables scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        $('#userTable').DataTable({
            "paging": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "lengthChange": true,
            "pageLength": 10,
            "language": {
                "search": "Search Users:",
                "lengthMenu": "Show _MENU_ users per page",
                "info": "Showing page _PAGE_ of _PAGES_",
                "infoEmpty": "No users available",
                "zeroRecords": "No matching users found"
            }
        });
    });
</script>

<?= $this->endSection(); ?>
